def main():
    print("Hello from geo!")


if __name__ == "__main__":
    main()
