from units.registry import MultiplicationRegistry
from units.measures import SpecificWeight, Length, Stress

MultiplicationRegistry.register(
    SpecificWeight,
    Length,
    Stress,
)
